package pig;

public class RiskyPlayer extends Player {

	public boolean throwAgain(Player Opponent)
	{
		return true;
	}
	
	
}
