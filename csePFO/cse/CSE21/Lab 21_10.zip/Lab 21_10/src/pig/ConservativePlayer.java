package pig;

public class ConservativePlayer extends Player {
	
	public boolean throwAgain(Player Opponent){
		
		return false;
		
	}

 
	
}
