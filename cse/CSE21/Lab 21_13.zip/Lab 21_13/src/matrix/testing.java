package matrix;

public class testing {
	
	public static void main(String[] args)
	{
	
	int[][] david = new int[2][3];
	
	System.out.println(david.length);
	System.out.println(david[2].length);

}
}