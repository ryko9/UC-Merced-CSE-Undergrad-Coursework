
# include "my_viewer.h"

# include <sigogl/ui_button.h>
# include <sigogl/ui_radio_button.h>
# include <sig/sn_primitive.h>
# include <sig/sn_transform.h>
# include <sig/sn_manipulator.h>

# include <sigogl/ws_run.h>

static void my_polyed_callback ( SnPolyEditor* pe, enum SnPolyEditor::Event e, int pid )
{
	MyViewer* v = (MyViewer*)pe->userdata();
	if ( e==SnPolyEditor::PostMovement || e==SnPolyEditor::PostEdition || e==SnPolyEditor::PostInsertion )
	{	v->update_scene ();
	}
}

MyViewer::MyViewer ( int x, int y, int w, int h, const char* l ) : WsViewer(x,y,w,h,l)
{
	rootg()->add ( _polyed = new SnPolyEditor );
	rootg()->add ( _curveA = new SnLines2 );
	rootg()->add(_curveB = new SnLines2);
	rootg()->add(_curveC = new SnLines2);
	rootg()->add(_curveD = new SnLines2);

	_curveA->color ( GsColor(20,200,25) );
	_curveA->line_width ( 2.0f );

	rootg()->add(_curveB = new SnLines2);

	_curveB->color(GsColor(20, 200, 25));
	_curveB->line_width(2.0f);

	rootg()->add(_curveC = new SnLines2);

	_curveC->color(GsColor(20, 200, 25));
	_curveC->line_width(2.0f);

	rootg()->add(_curveD = new SnLines2);

	_curveD->color(GsColor(20, 200, 25));
	_curveD->line_width(2.0f);

	// you may add new curves here

	// set initial control polygon:
	_polyed->callback ( my_polyed_callback, this );
	_polyed->max_polygons (1);
	_polyed->solid_drawing (0);
	GsPolygon& P = _polyed->polygons()->push();
	P.setpoly ( "-2 -2  -1 1  1 0  2 -2" );
	P.open(true);

	// start:
	build_ui ();
	update_scene ();
	message() = "Click on polygon to edit, use Esc to switch edition mode, Del deletes selected points. Enjoy!";
}

void MyViewer::build_ui ()
{
	UiPanel *p;
	p = uim()->add_panel ( "", UiPanel::HorizLeft );

	p->add ( _viewA=new UiCheckButton ( "CurveA", EvViewCurveA, true ) );
	p->add ( _viewB=new UiCheckButton ( "CurveB", EvViewCurveB, true ) );
	p->add(_viewC = new UiCheckButton("CurveC", EvViewCurveC, true));
	p->add(_viewD= new UiCheckButton("CurveD", EvViewCurveD, true));

	p->add ( _slider=new UiSlider ( " dt:", EvDeltaT, 0,0,150 ) );
	_slider->separate();
	_slider->range ( 0.01f, 0.25f );

	p->add ( new UiButton ( "Exit", EvExit ) ); p->top()->separate();
}

// Use one function for each curve type. Feel free to update/adapt parameter list etc.


static GsPnt eval_bezier(float t, const GsArray<GsPnt2>& P)
{
	int size = P.size() - 1; //length of P array
	
	GsPnt2 val;
	GsPnt2 sum;
	int a = gs_fact(size);
	int i = 0;

	while(i != size + 1)
	{

		val = P[i] * ((a / (gs_fact(i) * gs_fact(size - i))) * gs_pow(t, i) * gs_pow(1 - t, size - i));

		sum += val;

		i++;
	}

	return sum;
}

static float numN(int i, int k, float t) { // k always = 3
	//Code taken from bSpline Lecture slides
	float ti = float(i);

	if (k == 1) {
		return ti <= t && t < ti + 1 ? 1.0f : 0;
	}
	else {
		return ((t - ti) / (k - 1)) * numN(i, k - 1, t) +
			((ti + k - t) / (k - 1)) * numN(i + 1, k - 1, t);
	}
}

static GsPnt2 eval_bspline(float t, int k, const GsArray<GsPnt2>& P)
{

	int size = P.size();

	GsPnt2 index;

	int i = 0;

	for(int i = 0; i < size; i++)
	{

		index += (P[i] * numN(i, 3, t));

		//i++;
	}

	return index;
}



static GsPnt2 eval_crspline(float t, const GsArray<GsPnt2>& P)
{
	int i = (int)t;

	int in1 = i + 1; //helper variables
	int in2 = i + 2;
	int in3 = i + 3;
	GsPnt p32 = P[in3] - P[in2];
	GsPnt2 p31 = P[in3] - P[in1];
	GsPnt2 p21 = P[in2] - P[in1];
	GsPnt2 p2i = P[in2] - P[i];
	GsPnt2 p1i = P[in1] - P[i];

	GsPnt2 a = (p31 / 2.0f);
	GsPnt2 b = (p2i) / 2.0f;

	GsArray<GsPnt2> O = GsArray<GsPnt2>(4);

	O[0] = P[in1];
	O[1] = P[in1] + b / (3.0f);
	O[2] = P[in2] - a / 3.0f;
	O[3] = P[in2];


	return eval_bezier(t - i, O);
}

static GsPnt2 calculateVal(float d0, float d1, GsPnt2 v0, GsPnt2 v1)
{

	return ((v1 * d0) + (v0 * d1)) / (d0 + d1);
}

static GsPnt2 eval_bospline(float t, const GsArray<GsPnt2>& P)
{
	
	GsPnt2 val;

	int i = (int)t;

	int in1 = i + 1; //helper variables
	int in2 = i + 2;
	int in3 = i + 3;

	GsPnt p32 = P[in3] - P[in2];
	GsPnt2 p31 = P[in3] - P[in1];
	GsPnt2 p21 = P[in2] - P[in1];
	GsPnt2 p2i = P[in2] - P[i];
	GsPnt2 p1i = P[in1] - P[i];
	

	GsPnt2 a1 = (p31 / 2.0f);
	GsPnt2 b1 = (p2i) / 2.0f;
	
	float d0 = (p1i).len();
	float d1 = (p21).len();

	GsPnt2 v0 = (p1i) / d0;
	GsPnt2 v1 = (p21) / d1;
	GsPnt2 v3 = calculateVal(d0, d1, v0, v1);

	float d00 = (p21).len();
	float d01 = (P[in3] - P[in2]).len();
	GsPnt2 v00 = (p21) / d00;
	GsPnt2 v01 = (p32) / d01;
	GsPnt2 v03 = calculateVal(d00, d01, v00, v01);


	GsArray<GsPnt2> O = GsArray<GsPnt2>(4);
	O[0] = P[in1];
	O[1] = P[in1] + (v3 * d1) / 3.0f;
	O[2] = P[in2] - (v03 * d00) / 3.0f;
	O[3] = P[in2];

	
	return eval_bezier(t - i, O); 


}


/* static GsPnt2 eval_curveX ( float t, const GsArray<GsPnt2>& P )
{
	GsPnt2 point = P[0]*(1.0f-t) + P.top()*t; // add the correct equations here

	return point;
}

static GsPnt2 eval_curveY ( float t, const GsArray<GsPnt2>& P )
{
	GsPnt2 point;

	// point = ...

	return point;
} */

void MyViewer::update_scene ()
{
	// Initializations:
	_curveA->init();
	_curveB->init();
	_curveC->init();
	_curveD->init();

	// Access the control polygon:
	GsPolygon& P = _polyed->polygon(0);
	float deltat = _slider->value();
	if ( _viewA->value() ) // show curve
	{
		// Add your curves below and select the correct one(s) to be displayed.
		// As an example, below we have a linear interpolation between endpoints:
		_curveA->begin_polyline();
		for ( float t=0; t<1.0f; t+=deltat ) // note: the t range may change according to the curve
		{	_curveA->push ( eval_bezier ( t, P ) );
		}
		_curveA->push ( P.top() ); // ensure final point is there
		_curveA->end_polyline();
	}

	if (_viewB->value()) // show curve
	{
		// Add your curves below and select the correct one(s) to be displayed.
		// As an example, below we have a linear interpolation between endpoints:
		_curveB->begin_polyline();
		for (float t = 2; t < P.size(); t += deltat) // note: the t range may change according to the curve
		{
			_curveB->push(eval_bspline(t, 3, P));
		}
		_curveB->push(P.top()); // ensure final point is there
		_curveB->end_polyline();
	}  

	if (_viewC->value()) // show curve
	{
		// Add your curves below and select the correct one(s) to be displayed.
		// As an example, below we have a linear interpolation between endpoints:
		_curveC->begin_polyline();
		for (float t = 0; t < 1.0f; t += deltat) // note: the t range may change according to the curve
		{
			_curveC->push(eval_crspline(t, P));
		}
		_curveC->push(P.top()); // ensure final point is there
		_curveC->end_polyline();
	}

	if (_viewD->value()) // show curve
	{
		// Add your curves below and select the correct one(s) to be displayed.
		// As an example, below we have a linear interpolation between endpoints:
		_curveD->begin_polyline();
		for (float t = 0; t < 1.0f; t += deltat) // note: the t range may change according to the curve
		{
			_curveD->push(eval_bospline(t, P));
		}
		_curveD->push(P.top()); // ensure final point is there
		_curveD->end_polyline();
	}
}

int MyViewer::uievent ( int e )
{
	switch ( e )
	{
		case EvViewCurveA:	update_scene(); return 1;
		case EvViewCurveB:	update_scene(); return 1;
		case EvViewCurveC:	update_scene(); return 1;
		case EvViewCurveD:	update_scene(); return 1;
		case EvDeltaT:		update_scene(); return 1;
		case EvExit: gs_exit();
	}
	return WsViewer::uievent(e);
}
