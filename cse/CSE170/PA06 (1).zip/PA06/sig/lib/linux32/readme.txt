This folder containts 32 bit libraries built with g++ in linux
