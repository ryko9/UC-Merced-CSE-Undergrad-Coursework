This folder containts 64 bit libraries built with g++ in linux
