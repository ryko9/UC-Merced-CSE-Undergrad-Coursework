=== SIG Main Documentation ===

An overall description of SIG is available in 
document sigdoc.pdf.

== REFERENCE MANUAL ==

A reference manual can be built with doxygen:

1) download and install doxygen in your system:
http://www.stack.nl/~dimitri/doxygen/download.html

2) from the command prompt, run:
doxygen doxyfile.txt
The html entry point will be refman/html/index.html

3) go to folder doxygen/latex/, and run make.bat
to build reference manual refman.pdf
